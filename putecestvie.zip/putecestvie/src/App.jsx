// src/App.jsx
import React from 'react';
import Navigation from './components/Navigation';
import HeroSection from './components/HeroSection';
import TravelCardsSection from './components/TravelCardsSection'; // ← новое

function App() {
  return (
    <>
      <Navigation />
      <HeroSection />
      <TravelCardsSection /> {/* ← вставляем сюда */}
    </>
  );
}

export default App;