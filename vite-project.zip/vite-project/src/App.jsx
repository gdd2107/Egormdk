// App.js
import { useState } from 'react';
import './App.css';

function App() {
  const [isOpen, setIsOpen] = useState(false);

  const open = () => setIsOpen(true);
  const close = () => setIsOpen(false);
  const OverlayClick = (event) => {
    if (event.target === event.currentTarget) {
      close();
    }
  };

  return (
    <>
      <button onClick={open}>открыть </button>

      {isOpen && (
        <div className="modal-overlay" onClick={OverlayClick}>
          <div className="modal-content">
            <button className="modal-close" onClick={close} aria-label="Закрыть">
              &times;
            </button>
            <h2>Гатин Ян</h2>
            <p>Лучший работник месяца </p>
            <button onClick={close}>Закрыть</button>
          </div>
        </div>
      )}
    </>
  );
}

export default App;